
#====================== Libraries ======================

library(readr)
library(dplyr)
library(ggplot2)
library(broom)
library(ggpubr)
library(readxl)
library(corrplot)

#====================== Import Data ======================

world_stats <- read.csv("world_stats.csv")
colnames(world_stats)[1] <- c("Remove")
colnames(world_stats)[2] <- c("Country")
# Contains data until 2016
# Duplicate entries
#GDP per capita (current US$)
#Mortality rate, infant (per 1,000 live births)
#Surface area (sq. km)
#Average precipitation in depth (mm per year)
#Access to electricity (% of population)

medals <- read.csv("athlete_events.csv")
medals <- unique.data.frame(medals) # Remove duplicate entries

olympic_codes <- read.csv("noc_regions.csv")
olympic_codes <- olympic_codes[,-3] # Remote notes column
colnames(olympic_codes) <- c('NOC', 'Country') # Rename 'region' to 'country'

#====================== Data Sets ======================

# [1] Medal data
# [2] World stats data
# [3] Olympic NOC data

#====================== Cleaning Data ======================

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Cleaning Dataset [1] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 


# show number of NA values
colSums(is.na(medals))
medals$Medal[is.na(medals$Medal)] <- "DNW"
# replace NA in medal column with DNW

colSums(is.na(medals))
# Verify no more NA in medals column

codes1 <- olympic_codes %>%
  distinct(NOC, Country) %>%
  group_by(Country) %>%
  summarize("count" = n())

choose <- which(codes1$count > 1)
codes1_new <- codes1[choose,]
# Displays countries who have more than 1 NOC code assigned

# Do the same to the medals tally

codes2 <- medals %>%
  distinct(NOC, Team) %>%
  group_by(NOC) %>%
  summarize("count" = n())

choose <- which(codes2$count > 1)
codes2_new <- codes2[choose,]

# Displays countries who have more than 1 NOC code assigned
# FRA has 160 different teams associated with it!

# Primary key will be the NOC
medals_countries <- left_join(olympic_codes, medals, by = 'NOC')

# Check again for non-fitting rows
colSums(is.na(medals_countries))
medals_countries[is.na(medals_countries$Medal),]
# Shows that SIN doesn't exist in medals record
medals_countries$NOC[is.na(medals_countries$region)]


# The missing countries are ROT, TUV, UNK
# For some reason SGP and HKG is not a code in the master NOC, so this had to be edited


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Cleaning Dataset [2] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

olympic_codes_append <- olympic_codes
rows <- nrow(olympic_codes_append)
olympic_codes_append[rows+1,] <- c("SGP", "Singapore")
olympic_codes_append[rows+2,] <- c("ZZX", "Olympic Mixed Team")

olympic_codes_append$Country[olympic_codes_append$NOC == 'BOL'] <- 'Bolivia'
olympic_codes_append$Country[olympic_codes_append$NOC == 'TUV'] <- 'Tuvalu'
olympic_codes_append$Country[olympic_codes_append$NOC == 'UNK'] <- 'Unknown'
olympic_codes_append$Country[olympic_codes_append$NOC == 'ROT'] <- 'Refugee Olympic Athletes'
olympic_codes_append$Country[olympic_codes_append$NOC == 'HKG'] <- 'Hong Kong'
# replace missing country names


# repeat
medals_countries <- left_join(olympic_codes_append, medals, by = 'NOC')
colSums(is.na(medals_countries))
medals_countries <- medals_countries[!is.na(medals_countries$ID),] 
# remote SIN row
colnames(medals_countries)[2] <- c('Country')

colSums(is.na(medals_countries))
# all fixed!

medals_countries <- unique.data.frame(medals_countries) # Remove duplicate entries



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Cleaning Dataset [3] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 


# get subset of world stats
namesvec <- c("Remove", "Country", "year", "GDP.per.capita..current.US..", "Population..total", "Rural.population....of.total.population.",
                                       "Land.area..sq..km.", "Access.to.electricity....of.population.", "Average.precipitation.in.depth..mm.per.year.")
world_stats_subset <- world_stats[,namesvec]
colnames(world_stats_subset)[1:3] <- c('Country', 'NOC', 'Year')

# Matching by NOC only
notmatched <- is.na(match(olympic_codes_append$NOC, world_stats_subset$NOC))
temp <- olympic_codes_append[notmatched,]
# We need to add proper codes to these countries listed!

# see if we can match by country name instead
matched <- is.na(match(temp$Country, world_stats_subset$Country))
temp <- olympic_codes_append[matched,]
# We need to add proper codes to these countries listed!

# adding proper NOC for countries that match
world_stats_subset2 <- left_join(world_stats_subset, olympic_codes_append, by = 'Country')
world_stats_subset2 <- world_stats_subset2[,-2]
colnames(world_stats_subset2)[9] <- 'NOC'

# Checking match by NOC again
notmatched <- is.na(match(olympic_codes_append$NOC, world_stats_subset2$NOC))
temp <- olympic_codes_append[notmatched,]
unique(temp$Country)

world_stats_subset2$Country[world_stats_subset2$Country == 'Antigua and Barbuda'] <- 'Antigua'
world_stats_subset2$Country[world_stats_subset2$Country == 'Bahamas, The'] <- 'Bahamas'
# found bolivia had an error on olympic codes append, line 116
world_stats_subset2$Country[world_stats_subset2$Country == 'Brunei Darussalam'] <- 'Brunei'
world_stats_subset2$Country[world_stats_subset2$Country == 'Congo, Rep.'] <- 'Republic of Congo'
world_stats_subset2$Country[world_stats_subset2$Country == "Cote d'Ivoire"] <- 'Ivory Coast'
world_stats_subset2$Country[world_stats_subset2$Country == 'Congo, Dem. Rep.'] <- 'Democratic Republic of the Congo'
#world_stats_subset2$Country[world_stats_subset2$Country == 'Cook Islands'] <- 'Cook Islands'
world_stats_subset2$Country[world_stats_subset2$Country == 'Cabo Verde'] <- 'Cape Verde'
world_stats_subset2$Country[world_stats_subset2$Country == 'Egypt, Arab Rep.'] <- 'Egypt'
world_stats_subset2$Country[world_stats_subset2$Country == 'Russian Federation'] <- 'Russia'
world_stats_subset2$Country[world_stats_subset2$Country == 'Micronesia, Fed. Sts.'] <- 'Micronesia'
world_stats_subset2$Country[world_stats_subset2$Country == 'Gambia, The'] <- 'Gambia'
world_stats_subset2$Country[world_stats_subset2$Country == 'United Kingdom'] <- 'UK'
world_stats_subset2$Country[world_stats_subset2$Country == 'Iran, Islamic Rep.'] <- 'Iran'
world_stats_subset2$Country[world_stats_subset2$Country == 'Virgin Islands (U.S.)'] <- 'Virgin Islands, US'
world_stats_subset2$Country[world_stats_subset2$Country == 'British Virgin Islands'] <- 'Virgin Islands, British'
world_stats_subset2$Country[world_stats_subset2$Country == 'Kyrgyz Republic'] <- 'Kyrgyzstan'
world_stats_subset2$Country[world_stats_subset2$Country == 'Korea, Rep.'] <- 'South Korea'
world_stats_subset2$Country[world_stats_subset2$Country == 'Lao PDR'] <- 'Laos'
world_stats_subset2$Country[world_stats_subset2$Country == 'St. Lucia'] <- 'Saint Lucia'
world_stats_subset2$Country[world_stats_subset2$Country == 'North Macedonia'] <- 'Macedonia'
#world_stats_subset2$Country[world_stats_subset2$Country == 'Palestine'] <- 'Palestine'
world_stats_subset2$Country[world_stats_subset2$Country == 'Korea, Dem. People�???Ts Rep.'] <- 'North Korea'
world_stats_subset2$Country[world_stats_subset2$Country == 'St. Kitts and Nevis'] <- 'Saint Kitts'
world_stats_subset2$Country[world_stats_subset2$Country == 'Slovak Republic'] <- 'Slovakia'
world_stats_subset2$Country[world_stats_subset2$Country == 'Eswatini'] <- 'Swaziland'
world_stats_subset2$Country[world_stats_subset2$Country == 'Syrian Arab Republic'] <- 'Syria'
#world_stats_subset2$Country[world_stats_subset2$Country == 'Taiwan'] <- 'Taiwan'
world_stats_subset2$Country[world_stats_subset2$Country == 'Trinidad and Tobago'] <- 'Trinidad'
world_stats_subset2$Country[world_stats_subset2$Country == 'United States'] <- 'USA'
world_stats_subset2$Country[world_stats_subset2$Country == 'Venezuela, RB'] <- 'Venezuela'
world_stats_subset2$Country[world_stats_subset2$Country == 'St. Vincent and the Grenadines'] <- 'Saint Vincent'
world_stats_subset2$Country[world_stats_subset2$Country == 'Yemen, Rep.'] <- 'Yemen'
world_stats_subset2$Country[world_stats_subset2$Country == 'Hong Kong SAR, China'] <- 'Hong Kong'
world_stats_subset2$Country[world_stats_subset2$Country == 'West Bank and Gaza'] <- 'Palestine'
world_stats_subset2$Country[world_stats_subset2$Country == 'Korea, Dem. People�???Ts Rep.'] <- 'North Korea'


# Checking match by country again
notmatched <- is.na(match(olympic_codes_append$Country, world_stats_subset2$Country))
temp <- olympic_codes_append[notmatched,]
unique(temp$Country)
# These countries have no population data in this set


# Adding proper NOC based on edited country names
world_stats_subset3 <- left_join(world_stats_subset2, olympic_codes_append, by = 'Country')
world_stats_subset3 <- world_stats_subset3[,-9]
colnames(world_stats_subset3) <- c('Country', 'Year', 'GDP per capita', 'Total Population', 'Rural Percentage', 'Land Area', 'Electricity Access', 'Precipitation', 'NOC')


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Limitations in Dataset [3] ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

# Limitations in world stats data for Taiwan, Cook Islands
colSums(is.na(world_stats_subset3))
notmatched <- is.na(match(olympic_codes_append$NOC, world_stats_subset3$NOC))
temp <- olympic_codes_append[notmatched,]
# These countries do not have world stats data
temp2 <- unique(temp$Country)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Final Joining ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

# Only keeping medal data 1960 onwards for merging with world stats
medals_countries_subset <- medals_countries[medals_countries$Year > 1959, ]
medals_stats <- left_join(medals_countries_subset, world_stats_subset3, by = c('Country','Year','NOC'))
medals_stats <- unique.data.frame(medals_stats) # Remove duplicate entries

colSums(is.na(medals_stats))

sum(!is.na(match(medals_stats$Country, temp2)))
# 1220 of athletes WITHOUT DATA total

str(medals_stats)
str(medals_countries)


#====================== Exploratory Data Analysis ======================

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Total Contingent by country (all years) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_CONTINGENT <- unique(medals_countries[ , c("Country", "Year", "Season", "Name", "Sex")])

medals_stats_SEX <- medals_stats_CONTINGENT
medals_stats_SEX[,c("Country", "Year", "Season", "Name", "Sex")] <- lapply(medals_stats_SEX[,c("Country", "Year", "Season", "Name", "Sex")], factor)
test <- aggregate(factor(medals_stats_SEX$Sex), by = medals_stats_SEX[,c("Country","Year","Season")], table)
test$x <- as.data.frame(test$x)
test$'Male' <- test$x$`M`
test$'Female' <- test$x$`F`
test <- select(test, -c(x))
medals_stats_SEX <- test

medals_stats_CONTINGENT[,c("Country","Year","Season")] <- lapply(medals_stats_CONTINGENT[,c("Country","Year","Season")], factor)
# Convert first 3 cols to factors
medals_stats_CONTINGENT <- data.frame(table(medals_stats_CONTINGENT[, c(1:3)]))
colnames(medals_stats_CONTINGENT)[4] <- c("Contingent")
# Disregard name, and count only unique athletes

medals_stats_CONTINGENT <- left_join(medals_stats_SEX, medals_stats_CONTINGENT, by = c("Country" = "Country", "Year" = "Year", "Season" = "Season"))
# Shows male and female too


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Total Contingent by year (all years) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_CONTINGENTyears <- unique(medals_countries[ , c("Year", "Season", "Name", "Sex")])

medals_stats_SEX <- medals_stats_CONTINGENTyears
medals_stats_SEX[,c("Year", "Season", "Name", "Sex")] <- lapply(medals_stats_SEX[,c("Year", "Season", "Name", "Sex")], factor)
test <- aggregate(factor(medals_stats_SEX$Sex), by = medals_stats_SEX[,c("Year","Season")], table)
test$x <- as.data.frame(test$x)
test$'Male' <- test$x$`M`
test$'Female' <- test$x$`F`
test <- select(test, -c(x))
medals_stats_SEX <- test

medals_stats_CONTINGENTyears[,c("Year","Season")] <- lapply(medals_stats_CONTINGENTyears[,c("Year","Season")], factor)
# Convert first 3 cols to factors
medals_stats_CONTINGENTyears <- data.frame(table(medals_stats_CONTINGENTyears[, c(1:2)]))
colnames(medals_stats_CONTINGENTyears)[3] <- c("Contingent")
# Disregard name, and count only unique athletes

medals_stats_CONTINGENTyears <- left_join(medals_stats_SEX, medals_stats_CONTINGENTyears, by = c("Year" = "Year", "Season" = "Season"))
# Shows male and female too



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 1 medal per participation (team events count more than 1 medal) All Years  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_TEAMS <- unique(medals_countries[ , c("Country", "Year", "Season", "Event", "Name", "Medal", "Sex")])

medals_stats_TEAMS_SEX <- medals_stats_TEAMS
medals_stats_TEAMS_SEX[,c("Country", "Year", "Season", "Event", "Name", "Medal", "Sex")] <- lapply(medals_stats_TEAMS_SEX[,c("Country", "Year", "Season", "Event", "Name", "Medal", "Sex")], factor)
test <- aggregate(factor(medals_stats_TEAMS_SEX$Medal), by = medals_stats_TEAMS_SEX[,c("Country","Year","Season","Sex")], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Teams' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Event Participations' <- apply(test$x[,c(1:4)], 1, sum)
test$'Bronze' <- test$x$Bronze
test$'Silver' <- test$x$Silver
test$'Gold' <- test$x$Gold
test$'DNW' <- test$x$DNW
test <- select(test, -c(x))
medals_stats_TEAMS_SEX <- test

medals_stats_TEAMS[,c("Country","Year","Season")] <- lapply(medals_stats_TEAMS[,c("Country","Year","Season")], factor)
test <- aggregate(factor(medals_stats_TEAMS$Medal), by = medals_stats_TEAMS[, c(1:3)], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Teams' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Event Participations' <- apply(test$x[,c(1:4)], 1, sum)

medals_stats_TEAMS <- left_join(test, medals_stats_CONTINGENT, by = c("Country" = "Country", "Year" = "Year", "Season" = "Season"))
# Includes previous data
medals_stats_TEAMS$'Bronze' <- medals_stats_TEAMS$x$Bronze
medals_stats_TEAMS$'Silver' <- medals_stats_TEAMS$x$Silver
medals_stats_TEAMS$'Gold' <- medals_stats_TEAMS$x$Gold
medals_stats_TEAMS$'DNW' <- medals_stats_TEAMS$x$DNW
medals_stats_TEAMS <- select(medals_stats_TEAMS, -c(x))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 1 medal per event (team events count for 1 medal) All Years  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_SINGULAR <- unique(medals_countries[ , c("Country", "Year", "Season", "Event", "Medal", "Sex")])

medals_stats_SINGULAR_SEX <- medals_stats_SINGULAR
medals_stats_SINGULAR_SEX[,c("Country", "Year", "Season", "Event", "Medal", "Sex")] <- lapply(medals_stats_SINGULAR_SEX[,c("Country", "Year", "Season", "Event", "Medal", "Sex")], factor)
test <- aggregate(factor(medals_stats_SINGULAR_SEX$Medal), by = medals_stats_SINGULAR_SEX[,c("Country","Year","Season","Sex")], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Actual' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Bronze' <- test$x$Bronze
test$'Silver' <- test$x$Silver
test$'Gold' <- test$x$Gold
test$'DNW' <- test$x$DNW
test <- select(test, -c(x))
medals_stats_SINGULAR_SEX <- test

medals_stats_SINGULAR[,c("Country","Year","Season")] <- lapply(medals_stats_SINGULAR[,c("Country","Year","Season")], factor)
test <- aggregate(factor(medals_stats_SINGULAR$Medal), by = medals_stats_SINGULAR[, c(1:3)], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Actual' <- apply(test$x[,c(1,3,4)], 1, sum)

medals_stats_SINGULAR <- left_join(test, medals_stats_CONTINGENT, by = c("Country" = "Country", "Year" = "Year", "Season" = "Season"))
# Includes previous data
medals_stats_SINGULAR$'Bronze' <- medals_stats_SINGULAR$x$Bronze
medals_stats_SINGULAR$'Silver' <- medals_stats_SINGULAR$x$Silver
medals_stats_SINGULAR$'Gold' <- medals_stats_SINGULAR$x$Gold
medals_stats_SINGULAR$'DNW' <- medals_stats_SINGULAR$x$DNW
medals_stats_SINGULAR <- select(medals_stats_SINGULAR, -c(x))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Medals only grouped by season and country (all time) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_agg_sex <- unique(medals_countries[ , c("Country", "Year", "Season", "Event", "Medal", "Sex")])

medals_agg_sex[,c("Country", "Year", "Season", "Event", "Medal", "Sex")] <- lapply(medals_agg_sex[,c("Country", "Year", "Season", "Event", "Medal", "Sex")], factor)
test <- aggregate(factor(medals_agg_sex$Medal), by = medals_agg_sex[,c("Country","Season","Sex")], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Actual' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Bronze' <- test$x$Bronze
test$'Silver' <- test$x$Silver
test$'Gold' <- test$x$Gold
test$'DNW' <- test$x$DNW
test <- select(test, -c(x))
medals_agg_sex <- test

medals_agg <- unique(medals_countries[ , c("Country", "Year", "Season", "Event", "Medal")])

medals_agg[,c("Country", "Year", "Season", "Event", "Medal")] <- lapply(medals_agg[,c("Country", "Year", "Season", "Event", "Medal")], factor)
test <- aggregate(factor(medals_agg$Medal), by = medals_agg[,c("Country","Season")], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Actual' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Bronze' <- test$x$Bronze
test$'Silver' <- test$x$Silver
test$'Gold' <- test$x$Gold
test$'DNW' <- test$x$DNW
test <- select(test, -c(x))
medals_agg <- test


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Medals only grouped by year (all time) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_agg_sex <- unique(medals_countries[ , c("Country", "Year", "Season", "Event", "Medal", "Sex")])
medals_agg_sex$Sex[medals_agg_sex$Sex == 'M'] <- 'Male'
medals_agg_sex$Sex[medals_agg_sex$Sex == 'F'] <- 'Female'


medals_agg_sex[,c("Year", "Season", "Event", "Medal", "Sex")] <- lapply(medals_agg_sex[,c("Year", "Season", "Event", "Medal", "Sex")], factor)
test <- aggregate(factor(medals_agg_sex$Medal), by = medals_agg_sex[,c("Year","Season","Sex")], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Actual' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Bronze' <- test$x$Bronze
test$'Silver' <- test$x$Silver
test$'Gold' <- test$x$Gold
test$'DNW' <- test$x$DNW
test <- select(test, -c(x))
medals_agg_sex <- test
colnames(medals_agg_sex)[3] <- 'Gender'

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Medals and stats grouped by year and country > 1960 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_summarise <- unique(medals_stats[ , c(2, 11:12, 17:22)])
medals_stats_summarise[,c("Country","Year","Season")] <- lapply(medals_stats_summarise[,c("Country","Year","Season")], factor)

medals_stats_TEAMS_1960 <- left_join(medals_stats_summarise, medals_stats_TEAMS, by = c("Country" = "Country", "Year" = "Year", "Season" = "Season"))
medals_stats_SINGULAR_1960 <- left_join(medals_stats_summarise, medals_stats_SINGULAR, by = c("Country" = "Country", "Year" = "Year", "Season" = "Season"))

medals_stats_combined <- left_join(medals_stats_TEAMS_1960, medals_stats_SINGULAR_1960, by = c("Country" = "Country", "Year" = "Year", "Season" = "Season"))

medals_stats_combined <- select(medals_stats_combined, -c(4:9, 15:18, 26:32))
colnames(medals_stats_combined)[6:14] <- c("Male", "Female", "Contingent", 'GDP per capita', 'Total Population', 'Rural Percentage', 
                                           'Land Area', 'Electricity Access', 'Precipitation')

medals_stats_combined <- select(medals_stats_combined, "Country", "Year", "Season", "Total Medals Teams", "Total Medals Actual", "Event Participations", "Contingent", 
                                "Male", "Female", 'GDP per capita', 'Total Population', 'Rural Percentage', 
                                'Land Area', 'Electricity Access', 'Precipitation')

colSums(is.na(medals_stats_combined))
# Includes summer and winter > 1960

write.csv(medals_stats_combined, "combined.csv", row.names = FALSE)
write.csv(medals_stats_combined[medals_stats_combined$Year == '2012',], "2012.csv", row.names = FALSE)
write.csv(medals_stats_combined[medals_stats_combined$Year == '2000',], "2000.csv", row.names = FALSE)






