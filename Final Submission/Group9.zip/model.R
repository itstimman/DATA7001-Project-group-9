
#====================== Libraries ======================

library(ggplot2)
library(corrplot)
library(car)
library(carData)
library(reshape2)
library(psych)
library(rgl)
library(readr)
library(dplyr)
library(broom)
library(ggpubr)
library(readxl)


#====================== Import Data ======================

#data2012
a1 = read.csv("2012.csv", header=TRUE, stringsAsFactors=FALSE)
colnames(a1) <- c("Country", "Year", "Season", "Total Medals Teams", "Total Medals Actual", "Event Participations", "Contingent", 
                  "Male", "Female", 'GDP per capita', 'Total Population', 'Rural Percentage', 
                  'Land Area', 'Electricity Access', 'Precipitation')
a1 <- select(a1, 'GDP per capita', 'Total Population', 'Total Medals Teams')
colnames(a1) <- c('GDP', "Population", "medal")
a1 <- na.omit(a1)
a1 <- a1[a1$medal > 0, ]

a1v2 = read.csv("2012subset.csv", header=TRUE, stringsAsFactors=TRUE)

a2 = scale(a1) #Data standardization
a2 = data.frame(a2)
cor(a2, use = "complete.obs") #Linear correlation coefficient view

#====================== Making the data confess ======================

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Scatter plot ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
pairs.panels(a1[c("GDP","Population","medal")])

scatterplotMatrix(a1,smooth=F,spread=FALSE,main='Scatter Plot Matrix')

plot(a1$GDP, a1$medal)
plot(a1$Population, a1$medal)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Multiple linear regression of medal to GDP and Population ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

lm1 = lm(medal~.,a2)
summary(lm1)
#Stepwise regression to select variables
step(lm1)
#model checking
#Some inspection charts
par(mfrow=c(2,2)) 
plot(lm1)
#Test whether the hypothesis is satisfied

ncvTest(lm1)#Homoscedasticity test
durbinWatsonTest(lm1)#Independence test
vif(lm1)#Multicollinearity test
outlierTest(lm1)#Outlier test

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Power transformation to remove heteroscedasticity ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

boxTidwell(medal~GDP+Population, data=a1v2) #Find the best power value

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ New model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

#New model
lm2 <- lm(medal~I(Population^0.16127)+I(GDP^0.10468),data=a1)
summary(lm2)

#Comparison of residual plots of two models
plot(lm1,which = 1)
plot(lm2,which = 1)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ validation on 2000 Olympics ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

#data 2000

a3 = read.csv("2000.csv", header=TRUE, stringsAsFactors=TRUE)
colnames(a3) <- c("Country", "Year", "Season", "Total Medals Teams", "Total Medals Actual", "Event Participations", "Contingent", 
                  "Male", "Female", 'GDP per capita', 'Total Population', 'Rural Percentage', 
                  'Land Area', 'Electricity Access', 'Precipitation')
a3 <- select(a3, 'GDP per capita', 'Total Population', 'Total Medals Teams')
colnames(a3) <- c('GDP', "Population", "medal")
a3 <- na.omit(a3)

lm3 <- lm(medal~I(Population^0.16127)+I(GDP^0.10468), data=a3)
summary(lm3)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 3D plot of new model ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 

#3d
library(car)
library(MASS) # Causes errors with dplyr
library(rgl)

pic1 = scatter3d(medal~GDP+Population,data=a1,fit="smooth")

medal~I(Population^0.16127)+I(GDP^0.10468)

newpopulation = a1$Population^0.16127
newGDP = a1$GDP^0.10468

a4 = data.frame(a1$medal,newpopulation,newGDP)
a4
pic2 = scatter3d(a1.medal~newpopulation+newGDP,data=a4,fit="smooth")

persp3d(a1$medal,newpopulation,newGDP,col="skyblue")