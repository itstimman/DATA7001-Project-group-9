
#====================== Libraries ======================

library(readr)
library(dplyr)
library(ggplot2)
library(broom)
library(ggpubr)
library(readxl)
library(corrplot)
library(reshape2)

#====================== Run project_v2.R first! ======================


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Correlation Plot ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

corr_medals <- cor(medals_stats_combined[, c(4:7,10:15)], use = "complete.obs")

corrplot(corr_medals, tl.col = "black", tl.srt = 45, bg = "White",
         addCoef.col = "black",
         type = "lower")


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Historical Plot ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


ggplot(medals_stats, aes(x = `GDP per capita`, fill = as.factor(Year))) + 
  geom_histogram(data=subset(medals_stats, Year == '1992'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '1996'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2000'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2004'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2008'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2012'), alpha = 0.2) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("GDP per capita (US$)") +
  ylab("Number of Athletes per year") +
  scale_fill_brewer(palette = 'PRGn', name = "Year")


ggplot(medals_stats, aes(x = `Total Population`, fill = as.factor(Year))) + 
  geom_histogram(data=subset(medals_stats, Year == '1992'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '1996'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2000'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2004'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2008'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats, Year == '2012'), alpha = 0.2) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("Total Population") +
  ylab("Number of Athletes per year") +
  scale_fill_brewer(palette = 'PRGn', name = "Year")


ggplot(medals_stats_combined, aes(x = `Contingent`, fill = as.factor(Year))) + 
  geom_histogram(data=subset(medals_stats_combined, Year == '1992'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '1996'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2000'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2004'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2008'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2012'), alpha = 0.2) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("Size of Contingent") +
  ylab("Number of Athletes per year") +
  scale_fill_brewer(palette = 'RdBu', name = "Year")

mean(medals_stats_combined$Contingent[medals_stats_combined$Year == '1992'])

ggplot(medals_stats_combined, aes(x = `Event Participations`, fill = as.factor(Year))) + 
  geom_histogram(data=subset(medals_stats_combined, Year == '1992'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '1996'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2000'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2004'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2008'), alpha = 0.2) +
  geom_histogram(data=subset(medals_stats_combined, Year == '2012'), alpha = 0.2) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")) +
  scale_y_continuous(expand = c(0, 0)) +
  xlab("Total Event Participations") +
  ylab("Number of Athletes per year") +
  scale_fill_brewer(palette = 'RdBu', name = "Year")



ggplot(medals_stats_combined[medals_stats_combined$Country == c('Australia', 'USA', 'Afghanistan'),], aes(x=Year, y=`GDP per capita`, colour=`Country`, na.rm = TRUE)) +
  geom_point() +
  geom_smooth(fullrange=TRUE)

ggplot(data=medals_stats_combined, aes(medals_stats_combined$'Total Medals Actual', medals_stats_combined$'GDP per capita')) + 
  geom_point() +
  xlab("Total Medals") +
  ylab("GDP per capita") + 
  geom_smooth(method='lm')

ggplot(data=medals_stats_combined, aes(medals_stats_combined$'Total Medals Actual', medals_stats_combined$'Contingent')) + 
  geom_point() +
  xlab("Total Medals") +
  ylab("Number of Athletes in Contingent") +
  geom_smooth(method='lm')

ggplot(data=medals_stats_combined, aes(medals_stats_combined$'Total Medals Actual', medals_stats_combined$'Event Participations')) + 
  geom_point() +
  xlab("Total Medals") +
  ylab("Number of Event Participations") +
  geom_smooth(method='lm')



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Bar of each year, medals awarded only ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_summerv2 <- unique(medals_countries[ , c("Year", "Season", "Event", "Medal")])
medals_stats_summerv2[,c("Year","Season")] <- lapply(medals_stats_summerv2[,c("Year","Season")], factor)
test <- aggregate(factor(medals_stats_summerv2$Medal), by = medals_stats_summerv2[, c(1:2)], table)
test$x <- as.data.frame(test$x)

medals_stats_summerv2 <- test

#medals_stats_summerv2 <- data.frame(table(medals_stats_summerv2[, c(1:3)]))

medals_stats_summerv2$'Bronze' <- medals_stats_summerv2$x$Bronze
medals_stats_summerv2$'Silver' <- medals_stats_summerv2$x$Silver
medals_stats_summerv2$'Gold' <- medals_stats_summerv2$x$Gold
medals_stats_summerv2$'DNW' <- medals_stats_summerv2$x$DNW
medals_stats_summerv2 <- select(medals_stats_summerv2, -c(x))
medals_stats_summerv2 <- medals_stats_summerv2[medals_stats_summerv2$Season == 'Summer', ]

#write.csv(medals_stats_summerv2, "data1.csv", row.names = FALSE)
graphme <- read.csv("visualisation/data10.csv")
colnames(graphme)[1] <- c("Year")
graphme <- graphme[graphme$Medal != 'DNW',]
graphme$Year <- as.factor(graphme$Year)
graphme$Medal <- as.factor(graphme$Medal)
graphme$Medal <- factor(graphme$Medal, levels = c('Bronze', 'Silver', 'Gold')) # Puts bars in order
graphme$Season <- as.factor(graphme$Season)


ggplot(graphme[graphme$Season == "Summer",], aes(x = Year, Count, fill = Medal)) + 
  geom_bar(stat = "identity", width = 0.7, position = "dodge") +
  xlab("Olympic Year") +
  ylab("Number of Medals") +
  scale_fill_manual(values = c("Bronze" = "brown",
                               "Silver" = "grey",
                               "Gold" = "gold")) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")
    ) +
  scale_y_continuous(expand = c(0, 0))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Bar of each sport, medals awarded only ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 


medals_stats_summerv3 <- unique(medals_countries[ , c("Country", "Year", "Season", "Event", "Sport", "Medal")])
medals_stats_summerv3[,c("Sport","Season")] <- lapply(medals_stats_summerv3[,c("Sport","Season")], factor)
test <- aggregate(factor(medals_stats_summerv3$Medal), by = medals_stats_summerv3[, c("Sport", "Season")], table)
test$x <- as.data.frame(test$x)
medals_stats_summerv3 <- test

medals_stats_summerv3$'Bronze' <- medals_stats_summerv3$x$Bronze
medals_stats_summerv3$'Silver' <- medals_stats_summerv3$x$Silver
medals_stats_summerv3$'Gold' <- medals_stats_summerv3$x$Gold
medals_stats_summerv3$'DNW' <- medals_stats_summerv3$x$DNW
medals_stats_summerv3 <- select(medals_stats_summerv3, -c(x))
medals_stats_summerv3 <- medals_stats_summerv3[medals_stats_summerv3$Season == 'Summer', ]

write.csv(medals_stats_summerv3, "visualisation/data11.csv", row.names = FALSE)

graphme <- read.csv("visualisation/data110.csv")
colnames(graphme)[1] <- c("Sport")
graphme$Sport <- as.factor(graphme$Sport)
graphme$Medal <- as.factor(graphme$Medal)
graphme <- graphme[graphme$Medal != 'DNW',]
graphme$Medal <- factor(graphme$Medal, levels = c('Bronze', 'Silver', 'Gold')) # Puts bars in order

ggplot(graphme, aes(x = reorder(Sport, -Count), Count, fill = Medal)) + 
  geom_bar(stat = "identity", width = 0.7, position = "dodge") +
  xlab("Olympic Sports") +
  ylab("Number of Medals") +
  scale_fill_manual(values = c("Bronze" = "brown",
                               "Silver" = "grey",
                               "Gold" = "gold")) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey"),
    axis.text.x=element_text(angle = 45, vjust = 1, hjust=1)
    ) +
  scale_y_continuous(expand = c(0, 0))

#scale_fill_brewer(palette = "Spectral")
#RColorBrewer::display.brewer.all() to see what colours available
#panel.border = element_rect(colour = "grey", fill = NA),





#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ All stats for single Year by country ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

medals_stats_SINGLEYEAR <- medals_stats[medals_stats$Year == 2012, ]
colSums(is.na(medals_stats_SINGLEYEAR)) # See what we're missing data for
test <- aggregate(factor(medals_stats_SINGLEYEAR$Event), by = medals_stats_SINGLEYEAR["Country"], table)

# Split up participants into: Bronze, Silver, Gold, DNW, Total Medals
test <- aggregate(factor(medals_stats_SINGLEYEAR$Medal), by = medals_stats_SINGLEYEAR["Country"], table)
test$x <- as.data.frame(test$x)
test$'Total Medals' <- apply(test$x[,c(1,3,4)], 1, sum)
test$'Total Participants' <- apply(test$x[,c(1:4)], 1, sum)
test$'Total Contingent' <- apply(test$x[,c(1:4)], 1, sum)

# For single year, now includes country stats for that year
medals_stats_SINGLEYEAR <- left_join(test, unique(medals_stats_SINGLEYEAR[ , c(1, 2, 17:22)]), by = c('Country'))
medals_stats_SINGLEYEAR$'Medals per million' <- medals_stats_SINGLEYEAR$'Total Medals' / medals_stats_SINGLEYEAR$'Total Population' * 1e+06
medals_stats_SINGLEYEAR$'GDP Total' <- medals_stats_SINGLEYEAR$'GDP per capita' * medals_stats_SINGLEYEAR$'Total Population'



ggplot(data=medals_stats_SINGLEYEAR, aes(medals_stats_SINGLEYEAR$'Total Population')) + 
  geom_histogram() +
  xlab("Total Population of Country") +
  ylab("Number of Athletes")

ggplot(data=medals_stats_SINGLEYEAR, aes(medals_stats_SINGLEYEAR$'Medals per million', medals_stats_SINGLEYEAR$'GDP per capita')) + 
  geom_point() +
  xlab("Medals per capita (million)") +
  ylab("GDP per capita")

ggplot(data=medals_stats_SINGLEYEAR, aes(medals_stats_SINGLEYEAR$'GDP per capita')) + 
  geom_histogram() +
  xlab("GDP per capita") +
  ylab("Number of Athletes")



#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Medals per country coloured by sport (1 medal per event, all time) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

temp <- medals_countries[medals_countries$Season == 'Summer',]
medals_stats_SPORTS <- unique(temp[ , c("Country", "Year", "Event", "Sport", "Medal")])
test <- aggregate(factor(medals_stats_SPORTS$Medal), by = medals_stats_SPORTS[, c("Country", "Sport")], table)
test$x <- as.data.frame(test$x)
test$'Total Medals Actual' <- apply(test$x[,c(1,3,4)], 1, sum)
medals_stats_SPORTS <- test

medals_stats_SPORTS$'Bronze' <- medals_stats_SPORTS$x$Bronze
medals_stats_SPORTS$'Silver' <- medals_stats_SPORTS$x$Silver
medals_stats_SPORTS$'Gold' <- medals_stats_SPORTS$x$Gold
medals_stats_SPORTS$'DNW' <- medals_stats_SPORTS$x$DNW
medals_stats_SPORTS <- select(medals_stats_SPORTS, -c(x))
medals_stats_SPORTS$Sport <- factor(medals_stats_SPORTS$Sport, levels = c(
  'Athletics',
  'Swimming',
  'Wrestling',
  'Gymnastics',
  'Boxing',
  'Shooting',
  'Rowing',
  'Cycling',
  'Canoeing',
  'Fencing',
  'Weightlifting',
  'Judo',
  'Sailing',
  'Equestrian',
  'Diving',
  'Tennis',
  'Archery',
  'Art Competitions',
  'Taekwondo',
  'Modern Pentathlon',
  'Badminton',
  'Football',
  'Hockey',
  'Table Tennis',
  'Water Polo',
  'Basketball',
  'Volleyball',
  'Synchronized Swimming',
  'Rhythmic Gymnastics',
  'Beach Volleyball',
  'Trampolining',
  'Triathlon',
  'Figure Skating',
  'Polo',
  'Tug-Of-War',
  'Golf',
  'Baseball',
  'Rugby',
  'Softball',
  'Croquet',
  'Racquets',
  'Rugby Sevens',
  'Lacrosse',
  'Cricket',
  'Ice Hockey',
  'Jeu De Paume',
  'Motorboating',
  'Roque',
  'Alpinism',
  'Aeronautics',
  'Basque Pelota'
)) # Puts bars in order

medals_stats_SPORTS <- medals_stats_SPORTS[medals_stats_SPORTS$'Total Medals Actual' > 20, ]

ggplot(medals_stats_SPORTS, aes(x = reorder(Country, -`Total Medals Actual`), `Total Medals Actual`, fill = Sport)) + 
  geom_bar(stat = "identity", width = 0.7) +
  xlab("Country") +
  ylab("Number of Medals") +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey"),
    axis.text.x=element_text(angle = 45, vjust = 1, hjust=1)
  ) +
  scale_y_continuous(expand = c(0, 0))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Medals per country coloured by medal type (1 medal per event, all time) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


write.csv(medals_agg, "visualisation/data31.csv", row.names = FALSE)

graphme <- read.csv("visualisation/data310.csv")
graphme$Season <- as.factor(graphme$Season)
graphme$Country <- as.factor(graphme$Country)
graphme$Medal <- as.factor(graphme$Medal)
graphme <- graphme[graphme$Medal != 'DNW',]
graphme <- graphme[graphme$Season == 'Summer',]
graphme$Medal <- factor(graphme$Medal, levels = c('Bronze', 'Silver', 'Gold')) # Puts bars in order

graphme <- graphme[graphme$'Count' > 20, ]

ggplot(graphme, aes(x = reorder(Country, -Count), Count, fill = Medal)) + 
  geom_bar(stat = "identity", width = 0.7) +
  xlab("Country") +
  ylab("Number of Medals") +
  scale_fill_manual(values = c("Bronze" = "brown",
                               "Silver" = "grey",
                               "Gold" = "gold")) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey"),
    axis.text.x=element_text(angle = 45, vjust = 1, hjust=1)
  ) +
  scale_y_continuous(expand = c(0, 0))


ggplot(graphme, aes(x = reorder(Country, -graphme$Count), Count, fill = Medal)) + 
  geom_bar(stat = "identity", width = 0.7, position = 'fill') +
  geom_col(position = position_fill(reverse = FALSE)) +
  guides(fill = guide_legend(reverse = FALSE)) +
  xlab("Country") +
  ylab("Number of Medals") +
  scale_fill_manual(values = c("Bronze" = "brown",
                               "Silver" = "grey",
                               "Gold" = "gold")) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey"),
    axis.text.x=element_text(angle = 45, vjust = 1, hjust=1)
  ) +
  scale_y_continuous(expand = c(0, 0), labels = scales::percent)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Gender graph ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


write.csv(medals_stats_CONTINGENTyears, "visualisation/data41.csv", row.names = FALSE)

graphme <- read.csv("visualisation/data410.csv")
graphme$Year <- as.factor(graphme$Year)
graphme$Season <- as.factor(graphme$Season)
graphme$Gender <- as.factor(graphme$Gender)
graphme <- graphme[graphme$Season == 'Summer',]

graphme <- graphme[graphme$'Count' > 20, ]

ggplot(graphme, aes(x = Year, Count, fill = Gender)) + 
  geom_bar(stat = "identity", width = 0.7, position = "dodge") +
  xlab("Olympic Year") +
  ylab("Contingent") +
  scale_fill_manual(values = c("Male" = "lightblue",
                               "Female" = "orange")) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")
  ) +
  scale_y_continuous(expand = c(0, 0))


medals_agg_sex$Gender <- factor(medals_agg_sex$Gender, levels = c('Male','Female')) # Puts bars in order
ggplot(medals_agg_sex[medals_agg_sex$Season == 'Summer',], aes(x = Year, `Total Medals Actual`, fill = Gender)) + 
  geom_bar(stat = "identity", width = 1, position = 'fill') +
  xlab("Olympic Year") +
  ylab("Percentage of Medals") +
  scale_fill_manual(values = c("Male" = "lightblue",
                               "Female" = "orange")) +
  theme(
    panel.border = element_blank(),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "grey")
  ) +
  scale_y_continuous(expand = c(0, 0), labels = scales::percent)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Linear correlation plot for 2012 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Alter below for single year only
medals_stats_short <- medals_stats_combined[medals_stats_combined$Year == 2012, c(4:7, 10:15)]
medals_stats_short2 = melt(medals_stats_short, id.vars='Total Medals Actual', na.rm = TRUE)
medals_stats_short2 = medals_stats_short2[medals_stats_short2$`Total Medals Actual` > 0, ]

ggplot(medals_stats_short2, aes(y = 'Total Medals Actual')) +
  geom_jitter(aes(value,`Total Medals Actual`, colour=variable),) + 
  geom_smooth(aes(value,`Total Medals Actual`, colour=variable), method=lm, na.rm = TRUE, se = FALSE) +
  facet_wrap(~variable, scales="free_x") +
  labs(x = "Variable", y = "Number of Medals Won")
